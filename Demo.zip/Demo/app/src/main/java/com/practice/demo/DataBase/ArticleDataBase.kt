package com.practice.demo.DataBase

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.practice.demo.Data.ArticleDao
import com.practice.demo.NewsModels.Article
import com.practice.demo.Utils.Converters


@Database(entities = [Article::class], version = 1)
@TypeConverters(Converters::class)
abstract class ArticleDataBase : RoomDatabase() {
    abstract fun articleDao(): ArticleDao
    companion object{
        private var INSTANCE:ArticleDataBase?=null

        fun getDatabase(context: Context):ArticleDataBase{
            val tempInstance= ArticleDataBase.INSTANCE
            if(tempInstance!=null)
            {
                return tempInstance
            }
            synchronized(this){
                val instance= Room.databaseBuilder(
                    context.applicationContext,
                    ArticleDataBase::class.java,
                    name="User_db"
                ).build()
                return instance
            }
        }
    }
}