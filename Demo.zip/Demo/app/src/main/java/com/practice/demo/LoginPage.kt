package com.practice.demo

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.practice.demo.ViewModel.UserViewModel
import com.practice.demo.databinding.ActivityLoginPageBinding

class LoginPage : AppCompatActivity() {
    private lateinit var binding:ActivityLoginPageBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding=ActivityLoginPageBinding.inflate(LayoutInflater.from(this))
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val userViewModel=ViewModelProvider(this).get(UserViewModel::class.java)
        binding.login.setOnClickListener {
            userViewModel.readAll.observe(this, Observer {
                if(binding.email.text.toString()==it.get(0).email && binding.password.text.toString()==it.get(0).password){
                    startActivity(Intent(this,DashboardPage::class.java))
                }
            })
        }
        binding.register.setOnClickListener{
            startActivity(Intent(this,RegisterPage::class.java))
        }
    }
}