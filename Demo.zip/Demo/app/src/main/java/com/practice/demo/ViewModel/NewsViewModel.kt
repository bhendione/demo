package com.practice.demo.ViewModel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.practice.demo.NewsModels.NewsResponse
import com.practice.demo.Repository.NewsRepository
import com.practice.demo.Utils.Resource
import kotlinx.coroutines.launch
import retrofit2.Response

class NewsViewModel(newsRepository: NewsRepository): ViewModel()  {
    val news:MutableLiveData<Resource<NewsResponse>> = MutableLiveData()
    var pageNumber:Int=1
    val newsRepository=newsRepository

    init {
        getNews("us")
    }
    fun getNews(countryCode:String)=viewModelScope.launch {
        news.postValue(Resource.Loading())
        val response= newsRepository.getNews(countryCode, pageNumber)
        news.postValue(handleNewsResponse(response))
    }
    private fun handleNewsResponse(response: Response<NewsResponse>) :Resource<NewsResponse>{
        if(response.isSuccessful){
            response.body()?.let{
                return Resource.Success(it)
            }
        }
        return Resource.Error(response.message())

    }
}