package com.practice.demo.Repository

import androidx.lifecycle.LiveData
import com.practice.demo.Data.User
import com.practice.demo.Data.UserDao

class UserRepository(private val userDao: UserDao)
{
    val readAll: LiveData<List<User>> = userDao.readAll()
    suspend fun addUser(user: User){
        userDao.addUser(user)
    }
}