package com.practice.demo

import android.os.Bundle
import android.view.LayoutInflater
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.practice.demo.Adapter.NewsAdapter
import com.practice.demo.DataBase.ArticleDataBase
import com.practice.demo.Repository.NewsRepository
import com.practice.demo.Repository.NewsViewModelProviderFactory
import com.practice.demo.ViewModel.NewsViewModel
import com.practice.demo.databinding.ActivityDashboardPageBinding

class DashboardPage : AppCompatActivity() {
    lateinit var binding: ActivityDashboardPageBinding
    lateinit var viewModel:NewsViewModel
    lateinit var newsAdapter: NewsAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding=ActivityDashboardPageBinding.inflate(LayoutInflater.from(this))
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val newsRepository=NewsRepository(ArticleDataBase.getDatabase(this))
        val newsViewModelProviderFactory=NewsViewModelProviderFactory(newsRepository)
        viewModel=ViewModelProvider(this,newsViewModelProviderFactory).get(NewsViewModel::class.java)
        newsAdapter= NewsAdapter()
        binding.newsRecycler.apply {
            adapter=newsAdapter
            layoutManager=LinearLayoutManager(this.context)
        }
        viewModel.news.observe(this, Observer {
            it.data?.let {
                newsAdapter.differ.submitList(it.articles)
            }
        })
//        val news:MutableLiveData<Article> = MutableLiveData()
//        lifecycleScope.launch {
//            val response:Response<Article> =RetrofitInstance.api.getHeadlines("us","1",API_KEY)
//            news.postValue(response.body())
//        }
    }
}