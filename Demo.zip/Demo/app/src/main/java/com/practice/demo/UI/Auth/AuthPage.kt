package com.practice.demo.UI.Auth

import android.os.Bundle
import android.view.LayoutInflater
import android.view.MenuItem
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.practice.demo.R
import com.practice.demo.databinding.ActivityAuthPageBinding

class AuthPage : AppCompatActivity() {
    lateinit var binding:ActivityAuthPageBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding=ActivityAuthPageBinding.inflate(LayoutInflater.from(this))
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        binding.menu.apply {
            if(menu.getItem(0).itemId==R.id.mlogin)
            {
                menu.getItem(0).isEnabled=false
                replaceFrag(LoginFragment())
            }else{
                replaceFrag(RegisterFragment())
            }
            itemIconSize=0
            val temp: MenuItem =menu.getItem(1)
            val temp1: MenuItem =menu.getItem(0)
            setOnItemSelectedListener {item->
                if(item.itemId==R.id.mlogin)
                {
                    item.isEnabled=false
                    temp.isEnabled=true
                    replaceFrag(LoginFragment())
                }
                if(item.itemId==R.id.msignup)
                {
                    item.isEnabled=false
                    temp1.isEnabled=true
                    replaceFrag(RegisterFragment())
                }
                true
            }

        }

    }
    private fun replaceFrag(fragment: Fragment)
    {
        val fragmentManager: FragmentManager =supportFragmentManager
        val fragmentTransaction: FragmentTransaction =fragmentManager.beginTransaction()
        fragmentTransaction.replace(R.id.frame,fragment)
        fragmentTransaction.commit()
    }
}