package com.practice.demo.Repository

import com.practice.demo.API.RetrofitInstance
import com.practice.demo.DataBase.ArticleDataBase
import retrofit2.Retrofit

class NewsRepository(val db:ArticleDataBase) {
    suspend fun getNews(countryCode:String,pageNumber:Int)=RetrofitInstance.api.getHeadlines(countryCode,pageNumber)
}