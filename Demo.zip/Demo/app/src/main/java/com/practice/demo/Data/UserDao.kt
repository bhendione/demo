package com.practice.demo.Data

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface UserDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addUser(user: User)

    @Query("select * from user order by id")
    fun readAll():LiveData<List<User>>

    @Query("select * from user where email=:email")
    fun selectData(email:String):LiveData<List<User>>
}