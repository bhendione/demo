package com.practice.demo.NewsModels

data class Source(
    val id: String,
    val name: String
)