package com.practice.demo

import android.os.Bundle
import android.view.LayoutInflater
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.ViewModelProvider
import com.practice.demo.Data.User
import com.practice.demo.ViewModel.UserViewModel
import com.practice.demo.databinding.ActivityRegisterPageBinding

class RegisterPage : AppCompatActivity() {
    private lateinit var binding:ActivityRegisterPageBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding=ActivityRegisterPageBinding.inflate(LayoutInflater.from(this))
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val userViewModel=ViewModelProvider(this).get(UserViewModel::class.java)
        binding.register.setOnClickListener {
            val user:User= User(0,binding.fname.text.toString(),binding.lname.text.toString(),binding.dob.text.toString(),binding.email.text.toString(),binding.password.text.toString())
            userViewModel.addUser(user)
        }
    }
}