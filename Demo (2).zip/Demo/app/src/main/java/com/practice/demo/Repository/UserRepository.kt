package com.practice.demo.Repository

import androidx.lifecycle.LiveData
import com.practice.demo.data.User
import com.practice.demo.data.UserDao
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class UserRepository @Inject constructor(private val userDao: UserDao)
{
    val readAll: LiveData<List<User>> = userDao.readAll()
    suspend fun addUser(user: User){
        userDao.addUser(user)
    }
    fun selectData(email:String):LiveData<List<User>>{
        return userDao.selectData(email)
    }
}