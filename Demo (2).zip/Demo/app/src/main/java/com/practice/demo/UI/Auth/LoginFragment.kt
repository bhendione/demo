package com.practice.demo.UI.Auth

import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.Observer
import com.practice.demo.UI.Dashboard.DashboardPage
import com.practice.demo.ViewModel.UserViewModel
import com.practice.demo.databinding.FragmentLoginBinding
import kotlinx.coroutines.launch
import java.util.regex.Pattern

class LoginFragment : Fragment() {
    lateinit var binding: FragmentLoginBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding=FragmentLoginBinding.inflate(LayoutInflater.from(context),container,false)
        binding.email.apply {
            setOnFocusChangeListener { view, hasFocus ->
                if(!hasFocus){
                    if(!Patterns.EMAIL_ADDRESS.matcher(text.toString()).matches())
                    {
                        setError("Enter a valid email")

                    }
                }
            }
        }
        binding.password.apply {
            setOnFocusChangeListener { view, b ->
                if(!b){
                    if(text.toString().isEmpty())
                    {
                        setError("Enter a password")
                    }
                    else if(!Pattern.compile("^(?=.*[0-9])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+$).{8,}$").matcher(text.toString()).matches())
                    {
                        var message:String=""
                        if(text.toString().length<8)
                        {   message="Your Password should be longer than 8 letters containing\n"

                        }
                        setError(message+"At least one\nnumber\nSmall alphabet\nCapital Alphabet\nSpecial Character")
                    }
                }
            }
        }
        val userViewModel= ViewModelProvider(this)[UserViewModel::class.java]
        binding.login.setOnClickListener {
            if(binding.email.text.toString().isEmpty()||binding.password.text.toString().isEmpty())
            {
                setError()
            }
            else{
                lifecycleScope.launch {
                    userViewModel.selectData(binding.email.text.toString()).observe(viewLifecycleOwner,
                        Observer {
                            if(it.isEmpty())
                            {
                                Toast.makeText(context,"Check your Email and Password or Create an Account",
                                    Toast.LENGTH_LONG).show()
                            }
                            else{
                                if(binding.password.text.toString()!=it.get(0).password)
                                {
                                    Toast.makeText(context,"Check Password", Toast.LENGTH_LONG).show()
                                }
                                else{
                                    startActivity(Intent(context, DashboardPage::class.java))
                                }
                            }
                        })
                }
            }
        }
        return binding.root
    }
    private fun setError(){
        if(binding.email.text.toString().isEmpty())
        {
            binding.email.setError("Enter your email")
        }
        binding.password.apply{
            if(text.toString().isEmpty())
            {
                setError("Enter your password")
            }
        }
    }
}