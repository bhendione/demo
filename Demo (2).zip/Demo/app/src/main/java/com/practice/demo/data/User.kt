package com.practice.demo.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user")
data class User(
    @PrimaryKey(autoGenerate = true)
    val id:Int,
    val fname:String,
    val lname:String,
    val dob:String,
    val email:String,
    val password:String
)
