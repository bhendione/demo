package com.practice.demo.DataBase.module

import android.content.Context
import androidx.room.Room
import com.practice.demo.DataBase.UserDataBase
import com.practice.demo.data.UserDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DataBaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context):UserDataBase= Room.databaseBuilder(
        context.applicationContext,
        UserDataBase::class.java,
        name="User_db"
    ).build()

    @Provides
    fun provideUserDao(dataBase: UserDataBase) : UserDao= dataBase.userDao()
}