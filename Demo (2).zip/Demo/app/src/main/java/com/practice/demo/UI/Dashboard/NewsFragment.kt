package com.practice.demo.UI.Dashboard

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.practice.demo.Adapter.NewsAdapter
import com.practice.demo.DataBase.ArticleDataBase
import com.practice.demo.Repository.NewsRepository
import com.practice.demo.Repository.NewsViewModelProviderFactory
import com.practice.demo.ViewModel.NewsViewModel
import com.practice.demo.databinding.FragmentNewsBinding

class NewsFragment : Fragment() {

    lateinit var binding : FragmentNewsBinding
    lateinit var viewModel: NewsViewModel
    lateinit var newsAdapter: NewsAdapter
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding=FragmentNewsBinding.inflate(LayoutInflater.from(context),container,false)
        val newsRepository= NewsRepository(ArticleDataBase.getDatabase(requireContext()))
        val newsViewModelProviderFactory= NewsViewModelProviderFactory(newsRepository)
        viewModel= ViewModelProvider(this,newsViewModelProviderFactory).get(NewsViewModel::class.java)
        newsAdapter= NewsAdapter()
        binding.newsRecycler.apply {
            adapter=newsAdapter
            layoutManager= LinearLayoutManager(this.context)
        }
        viewModel.news.observe(viewLifecycleOwner, Observer {
            it.data?.let {
                newsAdapter.differ.submitList(it.articles)
            }
        })
        return binding.root
    }
}