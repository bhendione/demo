package com.practice.demo.UI.Auth

import android.app.DatePickerDialog
import android.os.Bundle
import android.util.Patterns
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.practice.demo.data.User
import com.practice.demo.ViewModel.UserViewModel
import com.practice.demo.databinding.FragmentRegisterBinding
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.regex.Pattern

class RegisterFragment : Fragment() {

    lateinit var binding:FragmentRegisterBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding=FragmentRegisterBinding.inflate(LayoutInflater.from(context),container,false)
        val userViewModel= ViewModelProvider(this).get(UserViewModel::class.java)
        binding.fname.setOnFocusChangeListener { view, b ->
            if(!b){
                if(binding.fname.text.toString().isEmpty())
                {
                    binding.fname.setError("Enter a First Name")
                }
            }

        }
        binding.lname.setOnFocusChangeListener { view, b ->
            if(binding.lname.text.toString().isEmpty())
            {
                binding.lname.setError("Enter a Last Name")
            }
        }
        binding.email.apply {
            setOnKeyListener { view, i,  keyEvent ->
                if(!Patterns.EMAIL_ADDRESS.matcher(text.toString()).matches())
                {
                    setError("Enter a valid email")

                }
                return@setOnKeyListener false
            }
        }
        binding.password.apply {
            setOnFocusChangeListener { view, b ->
                if(!b){
                    if(text.toString().isEmpty())
                    {
                        setError("Enter a password")
                    }
                    if(!Pattern.compile("^(?=.*[0-9])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+$).{8,}$").matcher(text.toString()).matches())
                    {
                        var message:String=""
                        if(text.toString().length<8)
                        {
                            message="Your Password should be longer than 8 letters containing\n"
                        }
                        setError(message+"At least one\nnumber\nSmall alphabet\nCapital Alphabet\nSpecial Character")
                    }
                }
            }
        }
        binding.cpassword.apply {
            setOnKeyListener { view, i, keyEvent ->
                if(!text.toString().equals(binding.password.text.toString()))
                {
                    setError("input text does not match the password")
                }
                return@setOnKeyListener false
            }
        }
        binding.dob.setOnFocusChangeListener { view, b ->
            if(b){
                datepicker(binding.dob)
            }
        }
        binding.register.setOnClickListener {
            if(binding.fname.text.toString().isEmpty()||binding.lname.text.toString().isEmpty()||binding.dob.text.toString().isEmpty()||binding.email.text.toString().isEmpty()||binding.password.text.toString().isEmpty()||binding.cpassword.text.toString().isEmpty()){
                Toast.makeText(context,"Enter all the empty field", Toast.LENGTH_LONG).show()
                setError()
            }
            else{
                var data:String=""
                lifecycleScope.launch {
                    userViewModel.selectData(binding.email.text.toString()).observe(viewLifecycleOwner,{
                        if(!it.isEmpty())
                        {
                            data=it.toString()
                        }
                        if(!data.isEmpty()) {
                            Toast.makeText(context,"Email is already taken", Toast.LENGTH_LONG).show()
                        }
                        else{
                            val user: User = User(0,binding.fname.text.toString(),binding.lname.text.toString(),binding.dob.text.toString(),binding.email.text.toString(),binding.password.text.toString())
                            userViewModel.addUser(user)
                            Toast.makeText(context,"User has been registered", Toast.LENGTH_LONG).show()
                        }

                    })

                }
            }

        }
        return binding.root
    }
    private fun setError(){
        if(binding.fname.text.toString().isEmpty())
        {
            binding.fname.setError("Enter a name")
        }
        if(binding.lname.text.toString().isEmpty())
        {
            binding.lname.setError("Enter a name")
        }
        if(binding.dob.text.toString().isEmpty())
        {
            binding.dob.setError("Enter your Date of Birth")
        }
        if(binding.email.text.toString().isEmpty())
        {
            binding.email.setError("Enter an email")
        }
        if(binding.password.text.toString().isEmpty())
        {
            binding.password.setError("Enter a password")
        }
        if(binding.cpassword.text.toString().isEmpty())
        {
            binding.cpassword.setError("Enter a password")
        }
    }
    private fun datepicker(date: EditText)
    {
        val calendar: Calendar = Calendar.getInstance()
        val y:Int=calendar.get(Calendar.YEAR)
        val m:Int=calendar.get(Calendar.MONTH)
        val d:Int=calendar.get(Calendar.DAY_OF_MONTH)
        val datePickerDialog: DatePickerDialog = DatePickerDialog(requireContext(),
            { view, year, month, dayOfMonth ->
                val calendar: Calendar = Calendar.getInstance()
                calendar.set(Calendar.DAY_OF_MONTH,dayOfMonth)
                calendar.set(Calendar.MONTH,month)
                calendar.set(Calendar.YEAR,year)
                val dateformate= SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                val format=dateformate.format(calendar.time)
                date.setText(format)
            }, y, m, d)
        datePickerDialog.show()
    }
}