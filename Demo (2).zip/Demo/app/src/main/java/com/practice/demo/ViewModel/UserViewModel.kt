package com.practice.demo.ViewModel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.practice.demo.data.User
import com.practice.demo.DataBase.UserDataBase
import com.practice.demo.Repository.UserRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class UserViewModel(application: Application):AndroidViewModel(application) {
    val readAll:LiveData<List<User>>
    private val repository:UserRepository
    init{
        val userDao=UserDataBase.getDatabase(application).userDao()
        repository=UserRepository(userDao)
        readAll=repository.readAll
    }
    fun selectData(email:String):LiveData<List<User>> {
        return repository.selectData(email)
    }
    fun addUser(user: User){
        viewModelScope.launch(Dispatchers.IO) {
            repository.addUser(user)
        }
    }
}