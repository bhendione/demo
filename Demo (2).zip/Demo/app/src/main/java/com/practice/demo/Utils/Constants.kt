package com.practice.demo.Utils

class Constants {
    companion object{
        const val API_KEY="0c8512b72c87431ea9449d4f17dd4219"
        const val SEARCH_DELAY  ="500L"
        const val BASE_URL="https://newsapi.org/"
        const val PAGE_SIZE="20"
    }
}